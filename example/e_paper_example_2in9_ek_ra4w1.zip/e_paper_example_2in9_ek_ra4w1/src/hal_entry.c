/*****************************************************************************
 * File         :   hal_entry.h
 * Author       :   OMURAISU
 * Date         :   2021-01-30
 * Function     :   Main routine
 * Info         :   This software is example program for Waveshare e-paper module
 *                  and Renesas Flexible Software Package (FSP).
 *
 *                  This software has been created with reference to the following materials
 *                  https://github.com/waveshare/e-Paper/tree/master/STM32
 *
 *                  Please refer to README.md for more detail/Usage info.
 *
 * The author(OMURAISU) does not take any responsibility caused by this material.
 * If you incorporate this material into your system, please be very careful.
 ****************************************************************************/

/* Pin connection
 * P106 -> LED0
 * P404 -> LED1
 *
 * GPIO P103       PMOD1-1  -> e-paper CS    #low active
 * SPI0 MOSI  P101 PMOD1-2  -> e-paper DIN
 * SPI0 MISO  P100 PMOD1-3  -- (NC)
 * SPI0 RSPCK P102 PMOD1-4  -> e-paper CLK
 * GND             PMOD1-5  -- e-paper GND
 * VCC             PMOD1-6  -- e-paper VCC
 *
 * GPIO P107       PMOD1-8  -> e-paper RST   #low active
 * GPIO P204       PMOD1-9  -> e-paper DC    #High: Data, Low: Command
 * GPIO P407       PMOD1-10 <- e-paper BUSY  #high active
 */

#include "hal_data.h"
#include "EPD_Test.h"

#define LED0_ON     R_PORT1->PCNTR3_b.PORR = (1 << 6)
#define LED0_OFF    R_PORT1->PCNTR3_b.POSR = (1 << 6)
#define LED1_ON     R_PORT4->PCNTR3_b.PORR = (1 << 4)
#define LED1_OFF    R_PORT4->PCNTR3_b.POSR = (1 << 4)

FSP_CPP_HEADER
void R_BSP_WarmStart(bsp_warm_start_event_t event);
FSP_CPP_FOOTER

void hal_entry(void) {

    fsp_err_t status = FSP_SUCCESS;

    status = R_SPI_Open(&g_spi0_ctrl, &g_spi0_cfg);
    if(FSP_SUCCESS != status) __BKPT(0);

    DEV_Config_Set(&g_spi0, BSP_IO_PORT_01_PIN_07, BSP_IO_PORT_01_PIN_03, BSP_IO_PORT_02_PIN_04, BSP_IO_PORT_04_PIN_07);
    EPD_2in9_test();


    while (1)
    {
        LED0_ON;
        LED1_ON;
        R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_SECONDS);
        LED0_OFF;
        LED1_OFF;
        R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_SECONDS);

    }
}

/*******************************************************************************************************************//**
 * This function is called at various points during the startup process.  This implementation uses the event that is
 * called right before main() to set up the pins.
 *
 * @param[in]  event    Where at in the start up process the code is currently at
 **********************************************************************************************************************/
void R_BSP_WarmStart(bsp_warm_start_event_t event) {
	if (BSP_WARM_START_RESET == event) {
#if BSP_FEATURE_FLASH_LP_VERSION != 0

        /* Enable reading from data flash. */
        R_FACI_LP->DFLCTL = 1U;

        /* Would normally have to wait tDSTOP(6us) for data flash recovery. Placing the enable here, before clock and
         * C runtime initialization, should negate the need for a delay since the initialization will typically take more than 6us. */
#endif
	}

	if (BSP_WARM_START_POST_C == event) {
		/* C runtime environment and system clocks are setup. */

		/* Configure pins. */
		R_IOPORT_Open(&g_ioport_ctrl, &g_bsp_pin_cfg);
	}
}
